// pages/detailed/detailed.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    banner_url: ['../../icons/detail.jpg', '../../icons/detail02.jpg'],
    indicatorDots: true,//是否显示指示点
    vertical: false,//是否为纵向
    autoplay: false,
    indicatorcolor: 'green',
    interval: 3000,//自动切换时长
    duration: 1000,//滑动时长
    contentList: [
      {
        shopping: '../../icons/banner01.png',
        // title: '高级人脉养成术 | 结识你生命中的“贵人”,让身价提升10倍',
        bt_text: '管理精英训练手册——让你成为一名优秀的管理者'
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  }

  
})